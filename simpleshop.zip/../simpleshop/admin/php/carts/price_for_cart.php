<?php
	$cart = SimpleShop::current_cart();
	return $cart;
?>