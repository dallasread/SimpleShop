<?php
	$cart = SimpleShop::current_cart( $cart );
	return $cart;
?>