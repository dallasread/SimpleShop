<p>
	<strong>Your order is now processing!</strong><br>
	You'll receive an email shortly with confirmation of your order.
</p>